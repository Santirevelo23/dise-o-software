package shape;

//clase principal
public class figura {
	//atributos
    private String color;
    private boolean filled;
    
    //constructor
    public figura() {
        super();
        color = "Red";
        filled = true;
    }
    
    public figura(String color, boolean filled) 
    {
        super();
        this.color = color;
        this.filled = filled;
    }
    //get y set
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color=color;
    }
    public boolean isFilled() {
        return filled;
    }
    
    public void setFilled(boolean filled) {
        this.filled = filled;
    }
    
    @Override
    public String toString() {
        return "Shape=[ color= " + color + ", filled= " + filled+"]";
    }
}
