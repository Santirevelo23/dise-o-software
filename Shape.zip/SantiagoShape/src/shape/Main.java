package shape;

public class Main {

    public static void main(String[] args) {
        circulo circle = new circulo();
        
        System.out.println(circle.toString());
        
        System.out.println("Area: " +  circle.getArea());
        System.out.println("Perimeter: " + circle.getPerimeter());
        System.out.println("");
        
        rectangulo rectangle = new rectangulo();
        
        System.out.println(rectangle.toString());
        System.out.println("");
        System.out.println("Area: " + rectangle.getArea());
        System.out.println("Perimeter: " + rectangle.getPerimeter());


        cuadrado square = new cuadrado(5);
        
        System.out.println(square.toString());
    }
}

