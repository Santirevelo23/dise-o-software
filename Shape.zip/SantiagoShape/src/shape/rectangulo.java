package shape;
//herencia
public class rectangulo extends figura {
	//atributos
    private double width;
    private double length;

    public rectangulo() {
        width = 1.0;
        length = 1.0;    
    }

    public rectangulo(double width, double length) {
        this.width = width;
        this.length = length;
    }

    public rectangulo(String color, boolean filled, double width, double length) {
        super(color, filled);
        this.width = width;
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getArea() {
        double area = this.width * this.length;
        return area;
    }

    public double getPerimeter() {
        double perimeter = 2 * (this.width + this.length);
        return perimeter;
    }

    @Override
    public String toString() {
        return "Rectangle=[ " + super.toString() + ", Width= " + width + ", Length= " + length+"]";
    }
}

