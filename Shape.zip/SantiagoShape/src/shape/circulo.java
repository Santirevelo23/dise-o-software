package shape;
//herencia
public class circulo extends figura {
	//atributos
    private double radius;
//constructor
    public circulo() {
        radius =1.0;
    }

    public circulo(double radius) {
        this.radius=radius;
    }

    public circulo(String color, boolean filled, double radius) {
        super(color, filled);
        this.radius = radius;
    }
    //get y set

    public double getRadius() {
        return radius;
    }
    public void setRadius(double radius) {
        this.radius=radius;
    }
    public double getArea() {
        double areaCalculated =Math.PI*this.radius*this.radius;
        return areaCalculated;
    }

    public double getPerimeter() {
        double circumference=2 * Math.PI*this.radius;
        return circumference;
    }

    @Override
    public String toString() {
        return "Circle=[ " + super.toString() + ", Radius= " + radius+"]";
    }
}
